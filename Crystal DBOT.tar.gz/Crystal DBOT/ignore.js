require('dotenv').config();
const moment = require('moment');
const os = require('os');
const ms = require('ms');
const {
    Client,
    GatewayIntentBits,
    PermissionsBitField,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ComponentType,
    ChannelType,
} = require('discord.js');
const handleTickets = require('./tickets');

const devs = ['772595594765008917'];


const PREFIX = ';';
const blueColor = 0x3498db;
const db = require('./database');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
    ],
});

const muteTimers = new Map();

async function getMutedRole(guild) {
    let mutedRole = guild.roles.cache.find((r) => r.name === 'Muted');
    if (!mutedRole) {
        try {
            mutedRole = await guild.roles.create({
                name: 'Muted',
                color: 'GRAY',
                reason: 'Create Muted role for muting users',
                permissions: [],
            });
            for (const [, channel] of guild.channels.cache) {
                if (channel.isTextBased()) {
                    await channel.permissionOverwrites.edit(mutedRole, {
                        SendMessages: false,
                        AddReactions: false,
                        Speak: false,
                    });
                }
            }
        } catch (e) {
            console.error('Failed to create Muted role:', e);
            return null;
        }
    }
    return mutedRole;
}

async function sendEmbed(channel, title, description, color = blueColor, fields = []) {
    const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(description);
    if (fields.length) embed.addFields(fields);
    return channel.send({ embeds: [embed] });
}

async function unmuteUser(guild, userId) {
    try {
        const member = await guild.members.fetch(userId);
        if (!member) return;

        const mutedRole = guild.roles.cache.find((r) => r.name === 'Muted');
        if (!mutedRole) return;

        if (member.roles.cache.has(mutedRole.id)) {
            await member.roles.remove(mutedRole, 'Timed mute expired');
            const channel = guild.systemChannel || guild.channels.cache.find((c) => c.isTextBased());
            if (channel)
                sendEmbed(
                    channel,
                    'User Unmuted',
                    `🔊 Unmuted **${member.user.tag}** (mute time expired).`
                );
        }
    } catch (e) {
        console.error(`Error unmuting user ${userId}:`, e);
    }
    muteTimers.delete(userId);
}

const xpDB = require('./levelingDB'); // Load once outside event
const getRequiredXP = (lvl) => 5 * Math.pow(lvl, 2) + 50 * lvl + 100;

client.once('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}`);
    client.user.setActivity(';help', { type: 'LISTENING' });
});

client.on('guildMemberAdd', async (member) => {
    const guild = member.guild;

    // Try to find a dedicated welcome channel
    const welcomeChannel =
    guild.channels.cache.find(
        (ch) =>
        ['welcome', '👋welcome', 'introductions', 'join-log', 'arrivals-and-departures', '👋・arrivals-and-departures'].includes(ch.name.toLowerCase()) &&
        ch.isTextBased()
    ) || guild.systemChannel;

    if (!welcomeChannel) return;

    const embed = new EmbedBuilder()
    .setColor(blueColor)
    .setTitle('New Member Joined')
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
    .setDescription(
        `Welcome **${member.user.tag}** to **${guild.name}**!\n\nMake sure to check out the rules and introduce yourself.`
    )
    .addFields(
        { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
               { name: 'Member Count', value: `${guild.memberCount}`, inline: true }
    )
    .setTimestamp();

    welcomeChannel.send({ embeds: [embed] }).catch(console.error);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;

    // XP System Logic
    const userId = message.author.id;
    const guildId = message.guild.id;

    const selectStmt = xpDB.prepare('SELECT * FROM xp WHERE user_id = ? AND guild_id = ?');
    const insertStmt = xpDB.prepare('INSERT OR IGNORE INTO xp (user_id, guild_id, xp, level) VALUES (?, ?, ?, ?)');
    const updateStmt = xpDB.prepare('UPDATE xp SET xp = ?, level = ? WHERE user_id = ? AND guild_id = ?');

    let row = selectStmt.get(userId, guildId);

    if (!row) {
        insertStmt.run(userId, guildId, 5, 1);
    } else {
        let newXP = row.xp + 5;
        let newLevel = row.level;
        const requiredXP = getRequiredXP(newLevel);

        if (newXP >= requiredXP) {
            newXP -= requiredXP;
            newLevel++;
            await sendEmbed(message.channel, 'Level Up!', `🎉 ${message.author} reached **level ${newLevel}**!`);
        }

        updateStmt.run(newXP, newLevel, userId, guildId);
    }

    // Command handling
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();


    const errorEmbed = (desc) => sendEmbed(message.channel, 'Error', `❌ ${desc}`, 0xe74c3c);
    const successEmbed = (desc) => sendEmbed(message.channel, 'Success', `✅ ${desc}`, 0x2ecc71);

    const ticketHandled = await handleTickets(message, args, sendEmbed, blueColor);
    if (ticketHandled) return;

    // dev help command
    if (command === 'devcommands') {
        if (!devs.includes(message.author.id)) {
            return sendEmbed(message.channel, 'Error', '❌ You do not have permission to use this command.', 0xe74c3c);
        }

        const pages = [
            {
                name: 'Developer Commands',
                commands: [
                    '`devcommand` — Test a developer-only command',
                    '`devinfo` — Show detailed bot info (dev only)',
          '`dm <userID> <message>` — DM a user (dev only)',
          '`servers` — List all servers the bot is in (dev only)',
          '`shutdown` — Shut down the bot (dev only)',
          '`restart` — Restart the bot (dev only)',
          '`setactivity <activity>` — Set bot activity status (dev only)',
          '`stats` — Display host information',
          '`eval <code>` — Evaluate JavaScript code (dev only)',
          '`reload <module>` — Reload a module from disk (dev only)',
                ],
            },
        ];

        let currentIndex = 0;

        const generateEmbed = () =>
        new EmbedBuilder()
        .setColor(blueColor)
        .setTitle(pages[currentIndex].name)
        .setDescription(pages[currentIndex].commands.join('\n'))
        .setFooter({ text: `Page ${currentIndex + 1} of ${pages.length}` });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
            .setCustomId('prev')
            .setLabel('Previous')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
                                                         new ButtonBuilder()
                                                         .setCustomId('next')
                                                         .setLabel('Next')
                                                         .setStyle(ButtonStyle.Secondary)
                                                         .setDisabled(pages.length <= 1)
        );

        const reply = await message.channel.send({
            embeds: [generateEmbed()],
                                                 components: [row],
        });

        const collector = reply.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: 60_000,
        });

        collector.on('collect', async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: 'This command is not for you.', ephemeral: true });
            }

            if (interaction.customId === 'prev') currentIndex--;
            else if (interaction.customId === 'next') currentIndex++;

            row.components[0].setDisabled(currentIndex === 0);
            row.components[1].setDisabled(currentIndex === pages.length - 1);

            await interaction.update({
                embeds: [generateEmbed()],
                                     components: [row],
            });
        });

        collector.on('end', () => {
            row.components.forEach(btn => btn.setDisabled(true));
            reply.edit({ components: [row] }).catch(() => {});
        });
    }



    // start of dev commands

    if (command === 'stats') {
        if (!devs.includes(message.author.id)) return errorEmbed("You don't have permission to use this command.");

        const memUsage = process.memoryUsage();
        const rssMB = (memUsage.rss / 1024 / 1024).toFixed(2);
        const heapUsed = (memUsage.heapUsed / 1024 / 1024).toFixed(2);

        const statsEmbed = new EmbedBuilder()
        .setColor(blueColor)
        .setTitle('📊 Runtime Stats')
        .addFields(
            { name: 'RAM (RSS)', value: `${rssMB} MB`, inline: true },
                   { name: 'Heap Used', value: `${heapUsed} MB`, inline: true }
        )
        .setFooter({ text: 'Crystal' })
        .setTimestamp();

        return message.channel.send({ embeds: [statsEmbed] });
    }

    if (command === 'devcommand') {
        if (!devs.includes(message.author.id)) {
            return sendEmbed(message.channel, 'Error', '❌ You do not have permission to use this command.', 0xe74c3c);
        }

        return sendEmbed(message.channel, 'Dev Command', '✅ This is a developer-only command.');
    }



    if (command === 'botinfo') {
        if (!devs.includes(message.author.id)) {
            return sendEmbed(message.channel, 'Error', '❌ You do not have permission to use this command.', 0xe74c3c);
        }

        const totalGuilds = client.guilds.cache.size;
        const totalUsers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);
        const uptime = moment.duration(client.uptime).humanize();

        const infoEmbed = new EmbedBuilder()
        .setColor(blueColor)
        .setTitle('Crystal Bot Info')
        .addFields(
            { name: 'Bot Tag', value: `${client.user.tag}`, inline: true },
            { name: 'Bot ID', value: client.user.id, inline: true },
            { name: 'Ping', value: `${client.ws.ping}ms`, inline: true },
            { name: 'Uptime', value: uptime, inline: true },
            { name: 'Servers', value: `${totalGuilds}`, inline: true },
            { name: 'Total Users', value: `${totalUsers}`, inline: true },
            { name: 'Platform', value: `${os.platform()} (${os.arch()})`, inline: true },
                   { name: 'Node.js', value: process.version, inline: true }
        )
        .setFooter({ text: 'Crystal' })
        .setTimestamp();

        return message.channel.send({ embeds: [infoEmbed] });
    }


    if (command === 'dm') {
        if (!devs.includes(message.author.id)) {
            return errorEmbed("You don't have permission to use this command.");
        }

        const userId = args.shift();
        const dmMessage = args.join(' ');
        if (!userId || !dmMessage) return errorEmbed('Usage: ;dm <userID> <message>');

        try {
            const user = await client.users.fetch(userId);
            await user.send(dmMessage);
            return sendEmbed(message.channel, 'DM Sent', `✅ Message sent to **${user.tag}**.`);
        } catch (e) {
            return errorEmbed('Failed to send DM. Maybe the user has DMs disabled.');
        }
    }



    if (command === 'servers') {
        if (!devs.includes(message.author.id)) {
            return errorEmbed("You don't have permission to use this command.");
        }

        const guilds = client.guilds.cache.map(g => `${g.name} (ID: ${g.id})`).join('\n');
        const output = guilds.length > 1900 ? guilds.slice(0, 1897) + '...' : guilds;

        return sendEmbed(message.channel, 'Servers', output || 'No servers found.');
    }


    if (command === 'shutdown') {
        if (!devs.includes(message.author.id)) {
            return errorEmbed("You don't have permission to use this command.");
        }

        await sendEmbed(message.channel, 'Shutdown', 'Bot is shutting down...');
        process.exit(0); // Stops the bot process
    }

    if (command === 'restart') {
        if (!devs.includes(message.author.id)) {
            return errorEmbed("You don't have permission to use this command.");
        }
        await sendEmbed(message.channel, 'Restart', 'Bot is restarting...');
        process.exit(1); // PM2 or Docker can restart your bot on exit code 1
    }

    if (command === 'setactivity') {
        if (!devs.includes(message.author.id)) {
            return errorEmbed("You don't have permission to use this command.");
        }
        const activity = args.join(' ');
        if (!activity) return errorEmbed('Please provide an activity message.');

        client.user.setActivity(activity, { type: 'PLAYING' });
        return sendEmbed(message.channel, 'Activity Updated', `Set activity to: **${activity}**`);
    }


    // end of dev commands

    if (command === 'kick') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            return errorEmbed("You don't have permission to kick members.");
        }
        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a valid user to kick.');
        if (!user.kickable) return errorEmbed('I cannot kick this user.');

        try {
            await user.kick();
            return successEmbed(`Kicked **${user.user.tag}**.`);
        } catch (e) {
            console.error(e);
            return errorEmbed('Failed to kick the user.');
        }
    }

    if (command === 'ban') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return errorEmbed("You don't have permission to ban members.");
        }
        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a valid user to ban.');
        if (!user.bannable) return errorEmbed('I cannot ban this user.');

        try {
            await user.ban();
            return successEmbed(`Banned **${user.user.tag}**.`);
        } catch (e) {
            console.error(e);
            return errorEmbed('Failed to ban the user.');
        }
    }




    // mute commands
    // Simple duration parser: "10m", "2h", etc.
    function parseDuration(input) {
        if (!input) return null;
        const match = input.match(/^(\d+)(s|m|h|d)$/i);
        if (!match) return null;

        const value = parseInt(match[1]);
        const unit = match[2].toLowerCase();

        const multipliers = {
            s: 1000,
            m: 60 * 1000,
            h: 60 * 60 * 1000,
            d: 24 * 60 * 60 * 1000,
        };

        return value * (multipliers[unit] || 0);
    }

    if (command === 'mute') {
        try {
            // Check permission
            if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
                return message.channel.send("❌ You don't have permission to mute members.");
            }

            // Check mentioned user
            const user = message.mentions.members.first();
            if (!user) {
                return message.channel.send('❌ Please mention a user to mute.');
            }

            // Parse duration
            const durationInput = args[1];
            const durationMs = parseDuration(durationInput);

            if (!durationMs || durationMs <= 0) {
                return message.channel.send('❌ Please specify a valid duration like `10m`, `1h`, `30s`, or `1d`.');
            }

            // Get reason
            const reason = args.slice(2).join(' ') || 'No reason provided';

            // Check if the bot can mute them
            if (!user.moderatable) {
                return message.channel.send("❌ I can't mute that user. My role might be lower.");
            }

            // Mute
            await user.timeout(durationMs, reason);
            return message.channel.send(`🔇 **${user.user.tag}** has been muted for **${durationInput}**.\n📝 Reason: ${reason}`);
        } catch (err) {
            console.error('Mute command error:', err);
            return message.channel.send('❌ Something went wrong while muting the user.');
        }
    }




    // unmute commands





    if (command === 'mute') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return errorEmbed("You don't have permission to mute members.");
        }

        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a valid user to mute.');

        // Check if duration is provided
        const duration = args[1];
        if (!duration) return errorEmbed('Please provide a duration (e.g., 10m, 1h, 1d).');

        // Parse duration
        const durationMs = ms(duration);
        if (!durationMs || durationMs < 60000 || durationMs > 2419200000) { // Between 1 minute and 28 days
            return errorEmbed('Please provide a valid duration between 1 minute and 28 days.');
        }

        // Get reason
        const reason = args.slice(2).join(' ') || 'No reason provided';

        // Check if user is already muted
        const existingMute = db.prepare(`
        SELECT * FROM mutes
        WHERE user_id = ? AND guild_id = ? AND active = 1
        `).get(user.id, message.guild.id);

        if (existingMute) {
            return errorEmbed('This user is already muted.');
        }

        try {
            // Get muted role
            const mutedRole = await getMutedRole(message.guild);
            if (!mutedRole) return errorEmbed('Failed to setup muted role.');

            // Add role to user
            await user.roles.add(mutedRole, `Muted by ${message.author.tag}: ${reason}`);

            // Calculate timestamps
            const now = Date.now();
            const endTime = now + durationMs;

            // Store mute in database
            db.prepare(`
            INSERT INTO mutes (
                user_id, guild_id, reason, muted_by,
                mute_start, mute_end, active
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            `).run(
                user.id,
                message.guild.id,
                reason,
                message.author.id,
                now,
                endTime,
                1
            );

            // Set up unmute timer
            const timer = setTimeout(() => {
                unmuteUser(message.guild, user.id);
            }, durationMs);

            muteTimers.set(user.id, timer);

            // Send confirmation
            return sendEmbed(
                message.channel,
                'User Muted',
                `🔇 Muted **${user.user.tag}** for **${duration}**.\n` +
                `**Reason:** ${reason}\n` +
                `**Muted by:** ${message.author.tag}`,
                0xe67e22
            );
        } catch (err) {
            console.error('Mute command error:', err);
            return errorEmbed('Failed to mute user. Please check my permissions and role hierarchy.');
        }
    }





    //end of mute start of unmute


    if (command === 'unmute') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return errorEmbed("You don't have permission to unmute members.");
        }

        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a valid user to unmute.');

        try {
            // Check if user is muted in database
            const activeMute = db.prepare(`
            SELECT * FROM mutes
            WHERE user_id = ? AND guild_id = ? AND active = 1
            `).get(user.id, message.guild.id);

            if (!activeMute) {
                return errorEmbed('This user is not currently muted.');
            }

            // Perform unmute
            await unmuteUser(message.guild, user.id);

            // Update database
            db.prepare(`
            UPDATE mutes SET active = 0
            WHERE user_id = ? AND guild_id = ? AND active = 1
            `).run(user.id, message.guild.id);

            return sendEmbed(
                message.channel,
                'User Unmuted',
                `🔊 Unmuted **${user.user.tag}**.\n` +
                `**Originally muted by:** <@${activeMute.muted_by}>\n` +
                `**Original reason:** ${activeMute.reason}`,
                0x2ecc71
            );
        } catch (err) {
            console.error('Unmute command error:', err);
            return errorEmbed('Failed to unmute user. Please check my permissions.');
        }
    }




    if (command === 'purge' || command === 'clear') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return errorEmbed("You don't have permission to manage messages.");
        }

        // Get the number - handles cases like ";purge10" or ";purge 10"
        const amountArg = message.content
        .slice(PREFIX.length)
        .trimStart()
        .slice(command.length)
        .trim();

        const amount = parseInt(amountArg, 10);

        if (isNaN(amount) || amount < 1 || amount > 100) {
            return errorEmbed("Please specify a valid number between 1 and 100.");
        }

        try {
            // Delete the command message first
            await message.delete().catch(() => {});

            // Delete the specified amount (we add 1 because bulkDelete doesn't count the command message)
            const messages = await message.channel.messages.fetch({ limit: amount + 1 });
            await message.channel.bulkDelete(messages, true);

            const confirmation = await successEmbed(`Deleted ${amount} messages.`);
            setTimeout(() => confirmation.delete().catch(() => {}), 5000);
        } catch (err) {
            console.error('Purge error:', err);
            return errorEmbed("Failed to delete messages. Make sure they're not older than 14 days.");
        }
    }




    if (command === 'servericon') {
        const guild = message.guild;
        const iconURL = guild.iconURL({ dynamic: true, size: 512 });
        if (!iconURL) return errorEmbed('This server has no icon.');

        const embed = new EmbedBuilder()
        .setColor(blueColor)
        .setTitle(`${guild.name} Server Icon`)
        .setImage(iconURL);

        return message.channel.send({ embeds: [embed] });
    }

    if (command === 'roles') {
        const roles = message.guild.roles.cache
        .filter((role) => role.id !== message.guild.id)
        .sort((a, b) => b.position - a.position)
        .map((role) => role.toString())
        .join(', ');

        return sendEmbed(
            message.channel,
            `Roles in ${message.guild.name}`,
            roles || 'No roles found.'
        );
    }

    if (command === 'addrole') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
            return errorEmbed("You don't have permission to manage roles.");
        }
        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a user.');

        const roleName = args.join(' ');
        if (!roleName) return errorEmbed('Please specify a role name.');

        const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === roleName.toLowerCase());
        if (!role) return errorEmbed('Role not found.');

        if (user.roles.cache.has(role.id)) {
            return errorEmbed('User already has this role.');
        }

        try {
            await user.roles.add(role);
            return successEmbed(`Added role **${role.name}** to **${user.user.tag}**.`);
        } catch (e) {
            console.error(e);
            return errorEmbed('Failed to add role.');
        }
    }

    if (command === 'removerole') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
            return errorEmbed("You don't have permission to manage roles.");
        }
        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a user.');

        const roleName = args.join(' ');
        if (!roleName) return errorEmbed('Please specify a role name.');

        const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === roleName.toLowerCase());
        if (!role) return errorEmbed('Role not found.');

        if (!user.roles.cache.has(role.id)) {
            return errorEmbed('User does not have this role.');
        }

        try {
            await user.roles.remove(role);
            return successEmbed(`Removed role **${role.name}** from **${user.user.tag}**.`);
        } catch (e) {
            console.error(e);
            return errorEmbed('Failed to remove role.');
        }
    }

    // Fun commands

    if (command === 'joke') {
        const jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "What do you get if you cross a cat with a dark horse? Kitty Perry.",
            "Why did the scarecrow win an award? Because he was outstanding in his field!",
            // Add more jokes here
        ];
        const joke = jokes[Math.floor(Math.random() * jokes.length)];
        return sendEmbed(message.channel, 'Joke 😂', joke);
    }

    if (command === 'cat') {
        try {
            // Fetch random cat picture from The Cat API
            const response = await fetch('https://api.thecatapi.com/v1/images/search?mime_types=jpg,png');
            if (!response.ok) throw new Error('Failed to fetch cat picture');

            const data = await response.json();
            if (!data[0] || !data[0].url) {
                return message.reply('❌ Could not get a cat picture right now.');
            }

            const embed = new EmbedBuilder()
            .setTitle("🐱 Here's a random cat picture!")
            .setColor(0xffaaff)
            .setImage(data[0].url)
            .setFooter({ text: 'Powered by The Cat API' });

            return message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Cat Picture Error:', error);
            return message.reply('❌ Failed to fetch a cat picture. Try again later.');
        }
    }





    if (command === '8ball') {
        if (!args.length) return errorEmbed('Please ask a question.');
        const answers = [
            "It is certain.",
            "Without a doubt.",
            "You may rely on it.",
            "Ask again later.",
            "Don't count on it.",
            "My reply is no.",
            "Very doubtful.",
            "Signs point to yes.",
            // Add more 8-ball answers here
        ];
        const response = answers[Math.floor(Math.random() * answers.length)];
        return sendEmbed(message.channel, 'Magic 8-Ball 🎱', `🎱 Question: ${args.join(' ')}\nAnswer: **${response}**`);
    }

    if (command === 'warn') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return errorEmbed("You don't have permission to warn members.");
        }

        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a user to warn.');

        // Remove the command prefix + command + mention from the content to extract the reason
        const mention = `<@${user.id}>`;
        const mentionNick = `<@!${user.id}>`;
        const withoutCommand = message.content.slice(PREFIX.length + command.length).trim();

        let reason = withoutCommand;

        if (withoutCommand.startsWith(mention)) {
            reason = withoutCommand.slice(mention.length).trim();
        } else if (withoutCommand.startsWith(mentionNick)) {
            reason = withoutCommand.slice(mentionNick.length).trim();
        } else {
            reason = args.slice(1).join(' ');
        }

        if (!reason) return errorEmbed('Please specify a reason.');

        db.prepare(`
        INSERT INTO warnings (user_id, guild_id, reason, date)
        VALUES (?, ?, ?, ?)
        `).run(user.id, message.guild.id, reason, new Date().toISOString());

        return successEmbed(`Warned **${user.user.tag}**.\nReason: \`${reason}\``);
    }




    if (command === 'warnings') {
        const user = message.mentions.members.first() || message.member;

        const rows = db.prepare(`
        SELECT reason, date FROM warnings
        WHERE user_id = ? AND guild_id = ?
        ORDER BY id DESC
        LIMIT 10
        `).all(user.id, message.guild.id);

        if (rows.length === 0) {
            return sendEmbed(message.channel, 'Warnings', `✅ **${user.user.tag}** has no warnings.`, blueColor);
        }

        const formatted = rows
        .map((w, i) => `**${i + 1}.** ${w.reason} - *${new Date(w.date).toLocaleString()}*`)
        .join('\n');

        return sendEmbed(message.channel, `Warnings for ${user.user.tag}`, formatted, 0xf1c40f);
    }


    if (command === 'clearwarnings') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return errorEmbed("You don't have permission to clear warnings.");
        }

        const user = message.mentions.members.first();
        if (!user) return errorEmbed('Please mention a user.');

        const changes = db.prepare(`
        DELETE FROM warnings
        WHERE user_id = ? AND guild_id = ?
        `).run(user.id, message.guild.id);

        if (changes.changes === 0) {
            return errorEmbed('This user has no warnings.');
        }

        return successEmbed(`Cleared ${changes.changes} warning(s) for **${user.user.tag}**.`);
    }


    if (command === 'fact') {
        const facts = [
            "Honey never spoils.",
            "Bananas are berries, but strawberries are not.",
            "Octopuses have three hearts.",
            // Add more facts here
        ];
        const fact = facts[Math.floor(Math.random() * facts.length)];
        return sendEmbed(message.channel, 'Fun Fact 🤓', fact);
    }


    if (command === 'ticket') {
        const guild = message.guild;
        const member = message.member;

        const existing = guild.channels.cache.find(
            (c) => c.name === `ticket-${member.user.username.toLowerCase()}` && c.type === ChannelType.GuildText
        );

        if (existing) {
            await sendEmbed(message.channel, 'Ticket', '🎫 You already have an open ticket.');
            return;
        }

        const channel = await guild.channels.create({
            name: `ticket-${member.user.username}`,
            type: ChannelType.GuildText,
            permissionOverwrites: [
                {
                    id: guild.roles.everyone.id,
                    deny: [PermissionsBitField.Flags.ViewChannel],
                },
                {
                    id: member.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
                },
                {
                    id: client.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
                },
                // Optional: Add staff role permissions here
            ],
        });

        await sendEmbed(
            channel,
            'New Ticket',
            `👋 Hello ${member}, staff will be with you shortly. Use \`close\` to close the ticket.`,
            blueColor
        );

        const filter = (m) => m.content.toLowerCase() === 'close' && m.member.id === member.id;
        const collector = channel.createMessageCollector({ filter, time: 10 * 60 * 1000 }); // 10 minutes

        collector.on('collect', async () => {
            await sendEmbed(channel, 'Closing Ticket', '🚪 This ticket will close in 5 seconds...');
            setTimeout(() => channel.delete().catch(() => {}), 5000);
        });

        return;
    }




    if (command === 'help') {
        const pages = [
            {
                name: 'Moderation',
                commands: [
                    '`kick` — Kick a user',
                    '`ban` — Ban a user',
                    '`mute [time]` — Mute a user (optionally timed)',
          '`unmute` — Unmute a user',
          '`warn [reason]` — Warn a user',
          '`warnings` — View warnings',
          '`clearwarnings` — Clear all warnings',
          '`purge [1-100]` — Delete messages',
          '`addrole [role]` — Give a role',
          '`removerole [role]` — Remove a role'
                ]
            },
            {
                name: 'Information',
                commands: [
                    '`userinfo` — Show user details',
                    '`avatar` — Show avatar',
                    '`servericon` — Show server icon',
                    '`roles` — List server roles',
                    '`serverinfo` — Show server information',
                    '`website` — Crystal website'
                ]
            },
            {
                name: 'Fun',
                commands: [
                    '`cat` — Random cat image',
                    '`joke` — Random joke',
                    '`8ball [question]` — Magic 8-ball',
                    '`fact` — Random fact',
                    '`weight` — Random weight generator',
                    '`flip` — Flip a coin',
                    '`roll [sides]` — Roll a dice'
                ]
            },
            {
                name: 'Utility',
                commands: [
                    '`say [message]` — Make the bot say something',
                    '`ticket` — Open a support ticket',
                    '`ping` — Check bot latency',
                    '`help` — Show this menu'
                ]
            }
        ];

        let currentIndex = 0;

        const generateEmbed = () =>
        new EmbedBuilder()
        .setColor(blueColor)
        .setTitle(`${pages[currentIndex].name} Commands`)
        .setDescription(pages[currentIndex].commands.join('\n'))
        .setFooter({ text: `Page ${currentIndex + 1} of ${pages.length}` });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
            .setCustomId('prev')
            .setLabel('Previous')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
                                                         new ButtonBuilder()
                                                         .setCustomId('next')
                                                         .setLabel('Next')
                                                         .setStyle(ButtonStyle.Secondary)
                                                         .setDisabled(pages.length <= 1)
        );

        const reply = await message.channel.send({
            embeds: [generateEmbed()],
                                                 components: [row]
        });

        const collector = reply.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: 60_000
        });

        collector.on('collect', async (interaction) => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({ content: 'This help menu is not for you.', ephemeral: true });
            }

            if (interaction.customId === 'prev') currentIndex--;
            else if (interaction.customId === 'next') currentIndex++;

            row.components[0].setDisabled(currentIndex === 0);
            row.components[1].setDisabled(currentIndex === pages.length - 1);

            await interaction.update({
                embeds: [generateEmbed()],
                                     components: [row]
            });
        });

        collector.on('end', () => {
            row.components.forEach((btn) => btn.setDisabled(true));
            reply.edit({ components: [row] }).catch(() => {});
        });
    }





    // Example fix: say command deletes the user message - wrap in try/catch to avoid crash if deletion fails
    if (command === 'say') {
        const sayMessage = args.join(' ');
        if (!sayMessage) {
            return message.reply({
                embeds: [new EmbedBuilder()
                .setColor(0xff0000)
                .setDescription('❌ Please provide a message for me to say.')
                ]
            });
        }

        try {
            await message.delete(); // Try deleting the command message
        } catch (err) {
            console.warn('Failed to delete message:', err);
        }

        return message.channel.send({ content: sayMessage });
    }

    if (command === 'avatar') {
        const user = message.mentions.users.first() || message.author;
        const avatarURL = user.displayAvatarURL({ dynamic: true, size: 512 });

        const avatarEmbed = new EmbedBuilder()
        .setTitle(`${user.username}'s Avatar`)
        .setURL(avatarURL)
        .setImage(avatarURL)
        .setColor(0x3498db)
        .addFields({ name: 'Direct Link', value: `[Click to view avatar](${avatarURL})` });

        return message.channel.send({ embeds: [avatarEmbed] });
    }


    if (command === 'userinfo') {
        const user = message.mentions.members.first() || message.member;
        const joined = user.joinedAt.toDateString();
        const created = user.user.createdAt.toDateString();
        const mutedRole = message.guild.roles.cache.find((r) => r.name === 'Muted');
        const isMuted = mutedRole ? user.roles.cache.has(mutedRole.id) : false;

        const rolesList = user.roles.cache
        .filter((r) => r.id !== message.guild.id)
        .map((r) => r.name)
        .join(', ') || 'None';

        const userEmbed = new EmbedBuilder()
        .setColor(blueColor)
        .setTitle(`${user.user.tag} Info`)
        .setThumbnail(user.user.displayAvatarURL({ dynamic: true, size: 512 }))
        .addFields(
            { name: 'User ID', value: user.id, inline: true },
            { name: 'Joined Server', value: joined, inline: true },
            { name: 'Account Created', value: created, inline: true },
            { name: 'Roles', value: rolesList },
            { name: 'Muted', value: isMuted ? 'Yes' : 'No', inline: true }
        );

        return message.channel.send({ embeds: [userEmbed] });
    }

    if (command === 'website') {
        return sendEmbed(
            message.channel,
            'Crystal Website',
            '[Visit the Crystal website](https://crystal-mc.xyz)',
                         blueColor
        );
    }

    // -- Fun commands examples --

    if (command === 'weight') {
        const weight = Math.floor(Math.random() * 600) + 1;
        return sendEmbed(message.channel, 'Weight', `You weigh ${weight} lbs.`);
    }

    if (command === 'flip') {
        const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
        return sendEmbed(message.channel, 'Coin Flip', `🪙 It's **${result}**!`);
    }

    if (command === 'roll') {
        let sides = parseInt(args[0]) || 6;
        if (sides < 2) sides = 6;
        const roll = Math.floor(Math.random() * sides) + 1;
        return sendEmbed(message.channel, 'Dice Roll', `🎲 You rolled a **${roll}** (1-${sides}).`);
    }

    // Add more fun commands as needed...

    // Handle unknown commands
    if (![
        'ping', 'help', 'say', 'avatar', 'userinfo', 'kick', 'ban', 'mute', 'unmute', 'purge', 'clear',
        'servericon', 'roles', 'addrole', 'removerole', 'serverinfo',
        'weight', 'cat', 'joke', '8ball', 'roll', 'flip', 'fact', 'devcommands'
    ].includes(command)) {
        return errorEmbed('Unknown command. Use `;help` to see the list of commands.');
    }
});

client.login(process.env.DISCORD_TOKEN);

